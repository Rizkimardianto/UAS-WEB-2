<nav class="navbar navbar-light bg-light justify-content-between body-login header-common" >
  <div class="container">
  <a class="navbar-brand text-light" href="dashboard.php">Relawan Covid 19</a>
  
  <a class="btn my-2 my-sm-0 text-light" href="delete_session.php" type="submit">logout</a>
  </div>
</nav>